# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2025-12-02
- Initial SDK scaffold: payments, customers, invoices, webhooks
- Added split payments, subscriptions, payment links, installment plans, escrows
- Test scripts (mock and integration guards)
- Retry logic for 5xx responses
